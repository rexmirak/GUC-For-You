package exceptions;

public class WrongNumberException extends Exception {
	
	/**
	 * Karim Ahmed
	 */
	
	private static final long serialVersionUID = 1L;

	public WrongNumberException()
	{
		super();
	}

}
