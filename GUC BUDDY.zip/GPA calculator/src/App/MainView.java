package App;

import javax.swing.*;
import java.awt.*; 

public class MainView extends JFrame{
	
	/*
	 * author Karim Ahmed
	 * 2021
	 * 
	 */
	private static final long serialVersionUID = 1L;
	Panel Panel;
	CourseGradePanel CourseGradePanel;
	optionPanel optionPanel;
	WelcomePanel WelcomePanel;
	appInfoPanel appInfoPanel;
	LowerGpa LowerGpa;
	
	
	public MainView ()
	{
        Panel = new Panel(this);
        CourseGradePanel= new CourseGradePanel(this);
        optionPanel = new optionPanel(this);
        WelcomePanel = new WelcomePanel(this);
        appInfoPanel = new appInfoPanel(this);
        LowerGpa = new LowerGpa(this);
        
        this.getContentPane().add(optionPanel); 
        this.getContentPane().add(WelcomePanel);
        this.getContentPane().add(Panel); Panel.setVisible(false);
        this.getContentPane().add(CourseGradePanel); CourseGradePanel.setVisible(false);
        this.getContentPane().add(appInfoPanel); appInfoPanel.setVisible(false);
        this.getContentPane().add(LowerGpa); LowerGpa.setVisible(false);
        
//        Panel.setVisible(true);
        setTitle("Student Buddy");
        this.getContentPane().setLayout(null);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        setResizable(false);
		setBounds(200,100,1105,650);
		setVisible(true);
		
		setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("guc.png")));
		
		this.repaint();
		this.revalidate();
	}
	
	public static void main(String[] args) {
		@SuppressWarnings("unused")
		MainView m = new MainView();
	}

}
