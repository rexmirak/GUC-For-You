package App;


import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledDocument;

	

public class WelcomePanel extends JLayeredPane implements ActionListener {
	
	/**
	 * Karim Ahmed
	 */
	
	private static final long serialVersionUID = 1L;
	
	MainView MainView;
	JTextPane L1;
	
	
	
	public WelcomePanel(MainView MainView)
	{
		this.MainView=MainView;
		
		this.setVisible(true);
        this.setBounds(300,0,785,600);
        this.setLayout(new BorderLayout());
        
		L1 = new JTextPane ();
		L1.setText("�Education is the most powerful weapon which you can use to change the world� \n� Nelson Mandela");
		StyledDocument doc = L1.getStyledDocument();
		SimpleAttributeSet center = new SimpleAttributeSet();
		StyleConstants.setAlignment(center, StyleConstants.ALIGN_CENTER);
		doc.setParagraphAttributes(0, doc.getLength(), center, false);
		
		L1.setEditable(true);
		L1.setFont(new Font(Font.SERIF, Font.ITALIC,  20));
//		L1.setBorder((BorderFactory.createLineBorder(Color.MAGENTA, 1)));
		L1.setBackground(new Color(255, 255, 255, 0));
		L1.setOpaque(false);
		L1.setEditable(false);
		
		this.add(L1,BorderLayout.NORTH);
		
		this.setBorder(BorderFactory.createLineBorder(Color.DARK_GRAY, 2));
		JLabel Welc = new JLabel();
		ImageIcon img = new ImageIcon(getClass().getResource("guc_785x602.jpg")); 
		Welc.setIcon(img);
		Welc.setBounds(0,0,785,600);
		this.add(Welc);

	}
	

	@Override
	public void actionPerformed(ActionEvent e) {
		
	}

}
