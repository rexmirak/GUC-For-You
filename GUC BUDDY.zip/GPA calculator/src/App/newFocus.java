package App;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
public class newFocus implements FocusListener{
	int i;
	public newFocus (int i)
	{
		this.i=i;
	}

	@Override
	public void focusGained(FocusEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void focusLost(FocusEvent e) {
		// TODO Auto-generated method stub
		
	}

}
